package com.example.laptop.tarea1permisos;

import android.content.Intent;
import android.net.Uri;
import android.provider.ContactsContract;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class App extends AppCompatActivity implements View.OnClickListener{

    private Button sm,llama,contac;
    private Intent intent = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.app);
        sm = (Button) findViewById(R.id.button);
        llama = (Button) findViewById(R.id.button2);
        contac = (Button) findViewById(R.id.button3);
        sm.setOnClickListener(this);
        llama.setOnClickListener(this);
        contac.setOnClickListener(this);
    }


    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.button){
            Toast.makeText(this, "Enviando Sms", Toast.LENGTH_SHORT).show();
            intent = new Intent(Intent.ACTION_VIEW, Uri.parse("sms:" + "6145169897" ));
            intent.putExtra("sms_body", "hola");
            startActivity(intent);
        }
        if (v.getId() == R.id.button2){
            Toast.makeText(this, "Llama Usuario", Toast.LENGTH_SHORT).show();
            intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + "0123456789"));
            startActivity(intent);

        }
        if (v.getId() == R.id.button3){
            Toast.makeText(this, "Viendo Contactos", Toast.LENGTH_SHORT).show();
            intent = new Intent(Intent.ACTION_PICK, ContactsContract.Contacts.CONTENT_URI);
            startActivity(intent);
        }
    }
}
